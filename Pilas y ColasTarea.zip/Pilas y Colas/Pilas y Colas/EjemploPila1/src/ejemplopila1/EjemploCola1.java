
package ejemplopila1;

/**
 *
 * @author adria
 */
public class EjemploCola1 {
    final int MAX = 3;
    String[] cola;
    int frente;
    int ultimo;

    // Constructor
    public EjemploCola1() {
        cola = new String[MAX];
        frente = 0;
        ultimo = -1;
    }

    // Verificar si está vacía
    private boolean colaVacia() {
        return (ultimo < frente);
    }

    // Verificar si está llena
    private boolean colaLlena() {
        return (ultimo == MAX - 1);
    }

    // Agregar al final de la cola
    public String pone(String dato) {
        if (colaLlena()) {
            return "Cola llena";
        } else {
            ultimo++;
            cola[ultimo] = dato;
            return "Elemento insertado en la cola";
        }
    }

    // Quitar del frente de la cola
    public String quita() {
        if (colaVacia()) {
            return "Subdesbordamiento - Cola Vacía";
        } else {
            String dato = cola[frente];
            frente++;
            return dato;
        }
    }
    
}
