package ejemplopila1;

/**
 *
 * @author BRS
 * Descripción: Ejemplificar el uso de pilas. en este proyecto crear una pila
 *          de 10 elementos que inserte nombres de personas.
 * FEcha: 28/10/2026
 */
public class EjemploPila1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PilaNombres objPila = new PilaNombres();
        System.out.println(objPila.pone("Adriana"));
        System.out.println(objPila.pone("Yuri"));
        System.out.println(objPila.pone("Uriel"));
        System.out.println(objPila.pone("Danna"));
        
        System.out.println(objPila.quita());
        System.out.println(objPila.quita());
        System.out.println(objPila.quita());
        System.out.println(objPila.quita());
    }
    
}
