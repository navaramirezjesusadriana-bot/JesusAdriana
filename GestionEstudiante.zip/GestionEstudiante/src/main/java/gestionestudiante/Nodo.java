package gestionestudiante;


public class Nodo {
    private Estudiante objEst;
    private Nodo liga;

    // Constructor
    public Nodo() {
        this.objEst = null;
        this.liga = null;
    }

    public void setObjEst(Estudiante objEst) {
        this.objEst = objEst;
    }

    public Estudiante getObjEst() {
        return objEst;
    }

    public void setLiga(Nodo liga) {
        this.liga = liga;
    }

    public Nodo getLiga() {
        return liga;
    }
    
}
