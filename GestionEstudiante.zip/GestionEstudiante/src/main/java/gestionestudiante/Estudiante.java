
package gestionestudiante;


public class Estudiante {
   private String numControl;
    private String nombre;
    private String apellidos;
    private String carrera;

    public Estudiante(String numControl, String nombre, String apellidos, String carrera) {
        this.numControl = numControl;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.carrera = carrera;
    }

    public String getNumControl() {
        return numControl;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getCarrera() {
        return carrera;
    }

    public String mostrarInformacion() {
        return "Numero de Control: " + numControl +
             "\nNombre: " + nombre + " " + apellidos +
             "\nCarrera: " + carrera +
             "\n---------------------------";
    }
    
}
