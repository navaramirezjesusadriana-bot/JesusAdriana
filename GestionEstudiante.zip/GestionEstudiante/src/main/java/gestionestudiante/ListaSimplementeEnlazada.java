
package gestionestudiante;


public class ListaSimplementeEnlazada {
    private Nodo inicio;

    public ListaSimplementeEnlazada(Nodo inicio) {
        this.inicio = inicio;
    }

    public void insertaInicio(Estudiante estudiante) {
        Nodo nuevo = new Nodo();
        nuevo.setObjEst(estudiante);
        nuevo.setLiga(inicio);
        inicio = nuevo;
    }

    public void recorreIterativo() {
        if(inicio == null) {
            System.out.println("La lista esta vacia.");
            return;
        }
        System.out.println("\n===== LISTA DE ESTUDIANTES =====");
        Nodo temporal = inicio;
        int contador = 1;
        while(temporal != null) {
            System.out.println("Estudiante " + contador);
            System.out.println(temporal.getObjEst().mostrarInformacion());
            temporal = temporal.getLiga();
            contador++;
        }
    }

    public boolean eliminarPorNumeroControl(String numControl) {
        if(inicio == null) {
            return false;
        }

        // Si es el primer nodo
        if(inicio.getObjEst().getNumControl().equals(numControl)) {
            inicio = inicio.getLiga();
            return true;
        }

        Nodo anterior = inicio;
        Nodo actual = inicio.getLiga();

        while(actual != null && !actual.getObjEst().getNumControl().equals(numControl)) {
            anterior = actual;
            actual = actual.getLiga();
        }

        if(actual == null) {
            return false;
        }

        anterior.setLiga(actual.getLiga());
        return true;
    }
}