

package gestionestudiante;

import java.util.Scanner;

public class GestionEstudiante {
    Scanner teclado; 
    Nodo p;
    Estudiante objEstudiante;
    ListaSimplementeEnlazada objLista; 
    
    public GestionEstudiante(){
        this.teclado = new Scanner(System.in);
        this.p = null;
        this.objLista = null;
        this.objEstudiante = null;
    }
    
    public static void main(String[] args) {
        GestionEstudiante principal = new GestionEstudiante();
        principal.ejecutarMenu();
    }
    
    public void ejecutarMenu() {
        int opc;                               
        do{
            opc = menuOpciones();
            switch(opc){
                case 1: // Registrar un estudiante
                    registrarEstudiante();                        
                    break;
                case 2: // Eliminar un estudiante
                    eliminarEstudiante();
                    break;
                case 3: // Mostrar lista
                    if(objLista != null) {
                        objLista.recorreIterativo();
                    } else {
                        System.out.println("No hay estudiantes registrados aun.");
                    }
                    break;
                case 4: // Salir
                    System.out.println("Saliendo del sistema...");
                    System.exit(0); 
                    break;
                default:
                    System.out.println("Opcion no valida. Intente nuevamente.");
            }
        } while (opc != 4);        
    }

    private int menuOpciones() {
        System.out.println("\n===== GESTION DE ESTUDIANTES =====");
        System.out.println("1. Registrar Estudiante");
        System.out.println("2. Eliminar Estudiante");
        System.out.println("3. Mostrar lista de Estudiantes");
        System.out.println("4. Salir");
        System.out.print("Elige opcion: ");
        return teclado.nextInt();
    }

    private void registrarEstudiante() {
        String numControl, nombre, apellidos, carrera;
        System.out.print("Numero de Control: ");
        numControl = teclado.next();
        System.out.print("Nombre: ");
        nombre = teclado.next();
        System.out.print("Apellidos: ");
        apellidos = teclado.next();
        System.out.print("Carrera: ");
        carrera = teclado.next();
        
        this.objEstudiante = new Estudiante(numControl, nombre, apellidos, carrera);        
        
        if(p == null){ // Es el primer nodo
            p = new Nodo();
            p.setObjEst(objEstudiante);
            p.setLiga(null);
            objLista = new ListaSimplementeEnlazada(p);
        } else {
            objLista.insertaInicio(this.objEstudiante);
        }
        System.out.println(" Estudiante registrado exitosamente.");
    }
    
    private void eliminarEstudiante() {
        if(objLista == null) {
            System.out.println("No hay estudiantes registrados.");
            return;
        }
        System.out.print("Ingrese el Número de Control del estudiante a eliminar: ");
        String numControl = teclado.next();
        boolean eliminado = objLista.eliminarPorNumeroControl(numControl);
        if(eliminado) {
            System.out.println(" Estudiante eliminado exitosamente.");
        } else {
            System.out.println(" Estudiante no encontrado.");
        }
    }
}

